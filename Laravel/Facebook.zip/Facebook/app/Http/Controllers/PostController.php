<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Post;

class PostController extends Controller
{

    public function postCreatePost(Request $request)
    {
        $this->validate($request,[
            'body' => 'required'
        ]);

        $post = new Post();
        $post->body = $request['body'];
        $message = "Post is Empty !";
        if ($request->user()->posts()->save($post)) {
            $message = "Post created successfully ! ";
        }

        return redirect('dashboard')->with(['message' => $message]);
    }
}

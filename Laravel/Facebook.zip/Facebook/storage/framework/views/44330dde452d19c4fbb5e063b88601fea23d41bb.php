<!DOCTYPE html>
<html lang="en">
<html >

     <title><?php echo $__env->yieldContent('title'); ?></title>

      <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <link rel="stylesheet"  href="<?php echo e(URL::to('src/css/main.css')); ?>">

    <body>
        <?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div>
        <?php echo $__env->yieldContent('content'); ?>

        </div>
    </body>
</html>
<?php /**PATH D:\Projects\ITI\Laravel\Facebook\resources\views/layouts/master.blade.php ENDPATH**/ ?>